# importing all the method from the python file.
from absenteeism_module import *

# extracting the model and scale file for deployment.
model = absenteeism_model('model','scale')

# cleaning the input data from the client.
model.load_and_clean_data('Absenteeism_new_data.csv')

# predicting the probablity of absenteeism.
print(model.predicted_outputs())

# predicting the probablity of abseentism (Save the CSV file)
#model.predicted_outputs().to_csv('Absenteeism_predictions_Result.csv', index = False)
